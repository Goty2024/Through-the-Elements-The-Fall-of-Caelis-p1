using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Proyectile : MonoBehaviour
{
    Rigidbody rb;
    Transform player;
    float ForceSpeed = 320f;
    float aimbotForceSpeed = 15f;

    void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        rb = GetComponent<Rigidbody>();
    }
    public void Throw(Vector3 horizontal, Vector3 vertical)
    {
        rb.AddForce(horizontal * ForceSpeed + vertical * ForceSpeed);
    }
    private void Update()
    {
        Vector3 directionToPlayer = (player.position - transform.position).normalized;
        rb.AddForce(directionToPlayer.x * aimbotForceSpeed, 0f, 0f);
    }
}
