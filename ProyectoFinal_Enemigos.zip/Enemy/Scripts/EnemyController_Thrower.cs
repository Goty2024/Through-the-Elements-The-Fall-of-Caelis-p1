using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController_Thrower : EnemyController
{
    [Header("Type of thrower")]
    [SerializeField] bool isBubbleThrower;

    [Header("Atacking Settings")]
    [SerializeField] GameObject projectilePrefab;

    float localSpeed = 2f;

    protected override void ChildAwake()
    {
        
    }

    protected override void ChildUpdate()
    {
        
    }

    protected override float ReturnSpeed()
    {
        return localSpeed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(waitToAttack());
        }
    }
    IEnumerator waitToAttack()
    {
        localSpeed = 0;
        yield return new WaitForSeconds(2);
        GameObject projectile = Instantiate(projectilePrefab, transform.forward + gameObject.transform.position, Quaternion.identity);
        if(isBubbleThrower)
        {
            projectile.GetComponent<Bubble>().Throw(transform.forward, transform.up);
        }
        else
        {
            projectile.GetComponent<Iman>().Throw(transform.forward, transform.up);
        }
        yield return new WaitForSeconds(4);
        localSpeed = 2;
    }
}