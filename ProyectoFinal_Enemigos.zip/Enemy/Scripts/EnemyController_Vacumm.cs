using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController_Vacumm : EnemyController
{
    [Header("Atacking Settings")]
    [SerializeField] GameObject pushCollider;
    [SerializeField] GameObject hitCollider;

    float localSpeed = 2f;

    protected override void ChildAwake()
    {
        
    }

    protected override void ChildUpdate()
    {
        
    }

    protected override float ReturnSpeed()
    {
        return localSpeed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(waitToAttack());
        }
    }
    IEnumerator waitToAttack()
    {
        localSpeed = 0;
        yield return new WaitForSeconds(2);
        pushCollider.gameObject.SetActive(true);
        hitCollider.gameObject.SetActive(true);
        yield return new WaitForSeconds(2);
        pushCollider.gameObject.SetActive(false);
        hitCollider.gameObject.SetActive(false);
        localSpeed = 2;
    }
}
