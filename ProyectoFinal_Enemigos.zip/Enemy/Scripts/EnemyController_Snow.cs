using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController_Snow : EnemyController
{
    [SerializeField] Rigidbody rb;
    [SerializeField] CapsuleCollider capsuleCollider;
    [SerializeField] SphereCollider sphereCollider;
    [SerializeField] GameObject hitCollider;

    bool activated;
    float localSpeed = 2f;

    protected override void ChildAwake()
    {
        activated = false;
    }

    protected override void ChildUpdate()
    {
        
    }

    protected override float ReturnSpeed()
    {
        return localSpeed;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !activated)
        {
            rb.AddForce(Vector3.up * 350f);
            StartCoroutine(ChangeColliders());
        }
        else if(other.CompareTag("Player"))
        {
            StartCoroutine(waitToAttack());
        }
    }

    IEnumerator ChangeColliders()
    {
        yield return new WaitForSeconds(1);
        capsuleCollider.enabled = false;
        sphereCollider.enabled = true;
        characterController.enabled = true;
        rb.isKinematic = true;
        activated = true;
    }
    IEnumerator waitToAttack()
    {
        localSpeed = 0;
        yield return new WaitForSeconds(2);
        hitCollider.gameObject.SetActive(true);
        yield return new WaitForSeconds(2);
        hitCollider.gameObject.SetActive(false);
        localSpeed = 2;
    }
}
