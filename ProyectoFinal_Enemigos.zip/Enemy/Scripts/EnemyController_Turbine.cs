using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController_Turbine : EnemyController
{
    [Header("Atacking Settings")]
    [SerializeField] GameObject pushCollider;

    protected override void ChildAwake()
    {
        
    }

    protected override void ChildUpdate()
    {
        
    }

    protected override float ReturnSpeed()
    {
        return 2f;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(waitToAttack());
        }
    }
    IEnumerator waitToAttack()
    {
        speed = 0;
        yield return new WaitForSeconds(2);
        pushCollider.gameObject.SetActive(true);
        yield return new WaitForSeconds(2);
        pushCollider.gameObject.SetActive(false);
        speed = 2;
    }
}
