using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController_Kamikaze : EnemyController
{
    [Header("Atacking Settings")]
    [SerializeField] GameObject hitCollider;

    float localSpeed = 2f;

    protected override void ChildAwake()
    {

    }

    protected override void ChildUpdate()
    {

    }

    protected override float ReturnSpeed()
    {
        if(state == State.Wandering)
        {
            localSpeed = 2f;
            return localSpeed;
        }
        else
        {
            localSpeed = 6f;
            return localSpeed;
        }
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(waitToAttack());
        }
    }
    IEnumerator waitToAttack()
    {
        localSpeed = 0;
        yield return new WaitForSeconds(2);
        hitCollider.gameObject.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        hitCollider.gameObject.SetActive(false);
        Destroy(gameObject);
    }
}
